using System;
using System.Data.SqlClient;
using System.Windows;
using AuthorizationPractice.Models;
using AuthorizationPractice.Services;

namespace AuthorizationPractice
{
    public partial class LoginWindow : Window
    {
        private readonly AuthService _authService = new AuthService();

        public LoginWindow()
        {
            InitializeComponent();
            LoginTextBox.Focus();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            ErrorTextBlock.Text = string.Empty;

            string login = LoginTextBox.Text?.Trim();
            string password = PasswordInput.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                ErrorTextBlock.Text = "Заполните все поля.";
                return;
            }

            try
            {
                User user = _authService.Authenticate(login, password);

                if (user != null)
                {
                    MainWindow mainWindow = new MainWindow(user);
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    ErrorTextBlock.Text = "Неверный логин или пароль, либо учётная запись отключена.";
                    PasswordInput.Clear();
                }
            }
            catch (SqlException)
            {
                MessageBox.Show(
                    "Не удалось подключиться к серверу базы данных.\n\n" +
                    "Проверьте, что SQL Server Express запущен и база AuthorizationPractice создана.",
                    "Ошибка подключения",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Произошла непредвиденная ошибка:\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }
    }
}
