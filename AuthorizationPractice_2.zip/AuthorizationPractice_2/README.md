# AuthorizationPractice (копия для другого студента)

Учебный модуль авторизации WPF + ADO.NET  
.NET Framework 4.7 • C# 7.3 • MS SQL Server 2022 Express

## Описание

Отдельное WPF-приложение, реализующее авторизацию пользователей по данным из базы `AuthorizationPractice (копия для другого студента)` с использованием ADO.NET (`System.Data.SqlClient`).

### Реализовано:

- Окно авторизации (`LoginWindow`)
- Главное окно с информацией о пользователе (`MainWindow`)
- Класс `Database` — единая строка подключения
- Модель `User`
- Сервис `AuthService` с параметризованным SQL-запросом
- Проверка пароля по PBKDF2-хешу (формат `iterations.salt.hash`)
- Проверка флага `IsActive`
- Обработка `SqlException` (недоступный SQL Server)
- Использование `using` для всех объектов ADO.NET

## Тестовые учётные записи

| Логин     | Пароль       | Роль          |
|-----------|--------------|---------------|
| admin     | Admin123!    | Администратор |
| support1  | Support123!  | Специалист    |
| user1     | User123!     | Пользователь  |

## Подготовка базы данных

1. Запустите SQL Server Management Studio.
2. Подключитесь к `.\SQLEXPRESS` (Windows Authentication).
3. Выполните скрипт `AuthorizationPractice (копия для другого студента).sql`.
4. Убедитесь, что появилась база `AuthorizationPractice (копия для другого студента)` с тремя пользователями.

## Сборка и запуск

1. Откройте `AuthorizationPractice (копия для другого студента).csproj` в Visual Studio 2019/2022.
2. Убедитесь, что целевая платформа — **.NET Framework 4.7**.
3. Соберите и запустите проект (F5).

## Структура проекта

```
AuthorizationPractice (копия для другого студента)/
├── LoginWindow.xaml(.cs)     — окно входа
├── MainWindow.xaml(.cs)      — главное окно после входа
├── Database.cs               — строка подключения
├── Models/User.cs            — модель пользователя
├── Services/AuthService.cs   — логика авторизации + PBKDF2
├── AuthorizationPractice (копия для другого студента).sql — скрипт создания БД
└── Screenshots/              — скриншоты работы
```

## Скриншоты

- `01_LoginWindow.png` — окно авторизации
- `02_SuccessfulLogin_Admin.png` — успешный вход (Администратор)
- `03_WrongPassword.png` — отказ при неверном пароле
- `04_DisabledAccount.png` — отказ при отключённой учётной записи

## Примечания

- Пароли в БД хранятся в виде PBKDF2-хешей, совместимых с `Rfc2898DeriveBytes`.
- SQL-запрос параметризован (`@Login`).
- Введённый пароль никогда не сохраняется в объекте `User`.
- Интерфейс и логика авторизации разделены.
