using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using AuthorizationPractice.Models;

namespace AuthorizationPractice.Services
{
    /// <summary>
    /// Сервис авторизации пользователей через ADO.NET.
    /// </summary>
    public class AuthService
    {
        /// <summary>
        /// Выполняет авторизацию пользователя по логину и паролю.
        /// Возвращает объект User при успехе или null при отказе.
        /// </summary>
        public User Authenticate(string login, string password)
        {
            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
                return null;

            const string sql = @"
                SELECT u.Id, u.Login, u.PasswordHash, u.FullName, u.RoleId, u.IsActive, r.Name AS RoleName
                FROM dbo.Users u
                INNER JOIN dbo.Roles r ON r.Id = u.RoleId
                WHERE u.Login = @Login";

            try
            {
                using (var connection = new SqlConnection(Database.ConnectionString))
                {
                    connection.Open();

                    using (var command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@Login", login);

                        using (var reader = command.ExecuteReader())
                        {
                            if (!reader.Read())
                                return null; // Пользователь не найден

                            bool isActive = reader.GetBoolean(reader.GetOrdinal("IsActive"));
                            if (!isActive)
                                return null; // Учётная запись отключена

                            string storedHash = reader.GetString(reader.GetOrdinal("PasswordHash"));

                            if (!VerifyPassword(password, storedHash))
                                return null; // Неверный пароль

                            // Успешная авторизация
                            return new User
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Login = reader.GetString(reader.GetOrdinal("Login")),
                                FullName = reader.GetString(reader.GetOrdinal("FullName")),
                                RoleId = reader.GetInt32(reader.GetOrdinal("RoleId")),
                                RoleName = reader.GetString(reader.GetOrdinal("RoleName")),
                                IsActive = isActive
                            };
                        }
                    }
                }
            }
            catch (SqlException)
            {
                // Пробрасываем исключение, чтобы UI мог показать понятное сообщение
                throw;
            }
        }

        /// <summary>
        /// Проверяет пароль по PBKDF2-хешу формата: iterations.saltBase64.hashBase64
        /// Совместим с Rfc2898DeriveBytes в .NET Framework 4.7.
        /// </summary>
        private static bool VerifyPassword(string password, string storedHash)
        {
            if (string.IsNullOrEmpty(storedHash))
                return false;

            string[] parts = storedHash.Split('.');
            if (parts.Length != 3)
                return false;

            if (!int.TryParse(parts[0], out int iterations) || iterations <= 0)
                return false;

            byte[] salt;
            byte[] expectedHash;

            try
            {
                salt = Convert.FromBase64String(parts[1]);
                expectedHash = Convert.FromBase64String(parts[2]);
            }
            catch
            {
                return false;
            }

            using (var pbkdf2 = new Rfc2898DeriveBytes(password, salt, iterations))
            {
                byte[] actualHash = pbkdf2.GetBytes(expectedHash.Length);
                return SlowEquals(actualHash, expectedHash);
            }
        }

        /// <summary>
        /// Сравнение массивов байт с постоянным временем (защита от timing-атак).
        /// </summary>
        private static bool SlowEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length)
                return false;

            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];

            return diff == 0;
        }
    }
}
