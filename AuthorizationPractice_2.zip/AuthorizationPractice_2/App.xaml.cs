using System.Windows;

namespace AuthorizationPractice
{
    public partial class App : Application
    {
    }
}
